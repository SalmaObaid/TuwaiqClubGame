import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { GameLogo } from "@/components/GameLogo";
import { TimerDisplay } from "@/components/TimerDisplay";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Play } from "lucide-react";
import { Input } from "@/components/ui/input";
import { BigButton } from "@/components/BigButton";

export default function Game() {
  const [, setLocation] = useLocation();
  const [isPlaying, setIsPlaying] = useState(false);
  const [showInput, setShowInput] = useState(true);
  const [playerName, setPlayerName] = useState("");
  const [time, setTime] = useState(0);
  const startTimeRef = useRef<number | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const hitSoundRef = useRef<HTMLAudioElement | null>(null);

  // Constants
  const TARGET_TIME = 10.0;
  const MAX_TIME = 15.0;

  useEffect(() => {
    // Initialize hit sound
    hitSoundRef.current = new Audio(
      "https://assets.mixkit.co/sfx/preview/mixkit-correct-answer-tone-2870.mp3",
    );
    hitSoundRef.current.volume = 5;
  }, []);

  const stopGame = useCallback(() => {
    if (!isPlaying) return;

    // Play short ding sound on hit
    if (hitSoundRef.current) {
      hitSoundRef.current.currentTime = 0;
      hitSoundRef.current.play().catch(() => {});
    }

    setIsPlaying(false);
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }

    // Calculate final time accurately
    const endTime = performance.now();
    const duration = (endTime - (startTimeRef.current || endTime)) / 1000;

    // Ensure we don't go below 0
    const finalTime = Math.max(0, duration);

    // Store name in localStorage for the session
    localStorage.setItem("tuwaiq_last_player", playerName);

    // Navigate to results
    setLocation(
      `/result?time=${finalTime.toFixed(3)}&name=${encodeURIComponent(playerName)}`,
    );
  }, [isPlaying, setLocation, playerName]);

  const updateTimer = useCallback(() => {
    if (!startTimeRef.current) return;

    const now = performance.now();
    const elapsed = (now - startTimeRef.current) / 1000;

    setTime(elapsed);

    if (elapsed >= MAX_TIME) {
      stopGame();
    } else {
      animationFrameRef.current = requestAnimationFrame(updateTimer);
    }
  }, [stopGame]);

  const startGame = () => {
    if (!playerName.trim()) return;
    setShowInput(false);
    setIsPlaying(true);
    setTime(0);
    startTimeRef.current = performance.now();
    animationFrameRef.current = requestAnimationFrame(updateTimer);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);

  // Interaction handlers
  const handleInteraction = (e: React.MouseEvent | React.TouchEvent) => {
    if (isPlaying) {
      stopGame();
    }
  };

  // Keyboard handler for spacebar
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === "Space" && isPlaying) {
        e.preventDefault();
        stopGame();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isPlaying, stopGame]);

  return (
    <div
      className="min-h-screen flex flex-col relative overflow-hidden touch-manipulation cursor-default select-none bg-white"
      onClick={handleInteraction}
    >
      {/* Header */}
      <div className="p-6 flex justify-between items-center z-10">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full hover:bg-purple-100"
          onClick={(e) => {
            e.stopPropagation();
            setLocation("/");
          }}
        >
          <ArrowLeft className="w-6 h-6 text-purple-700" />
        </Button>
        <div className="text-sm font-bold text-purple-900/40 uppercase tracking-widest">
          Target: 10.00s
        </div>
      </div>

      {/* Main Area */}
      <div className="flex-1 flex flex-col items-center justify-center -mt-20">
        <AnimatePresence mode="wait">
          {showInput ? (
            <motion.div
              key="input"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="w-full max-w-sm px-6 space-y-6 text-center"
              onClick={(e) => e.stopPropagation()}
            >
              <h2 className="text-2xl font-bold text-purple-900">
                Enter Your Name
              </h2>
              <Input
                placeholder="Your Name"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                className="text-center text-lg h-12"
                onKeyDown={(e) => e.key === "Enter" && startGame()}
              />
              <BigButton
                disabled={!playerName.trim()}
                onClick={startGame}
                icon={<Play className="w-6 h-6 fill-current" />}
                className="w-full"
              >
                Start Game
              </BigButton>
            </motion.div>
          ) : (
            <motion.div
              key="game"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center"
            >
              <div className="mb-4 text-xl font-bold text-purple-600">
                {playerName}
              </div>
              <motion.div
                animate={isPlaying ? { scale: [1, 1.02, 1] } : {}}
                transition={{ duration: 0.5, repeat: Infinity }}
                className="mb-12"
              >
                <GameLogo size="md" />
              </motion.div>

              <TimerDisplay time={time} isRunning={isPlaying} />

              <AnimatePresence>
                {isPlaying && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="mt-16 text-center"
                  >
                    <p className="text-2xl font-light text-muted-foreground animate-pulse">
                      Tap the logo to stop
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Progress Bar */}
      <div className="absolute bottom-0 left-0 w-full h-2 bg-purple-100">
        <motion.div
          className="h-full bg-gradient-to-r from-purple-400 to-pink-500"
          style={{ width: `${Math.min((time / TARGET_TIME) * 100, 100)}%` }}
        />
      </div>
    </div>
  );
}
